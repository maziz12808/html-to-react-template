import TopHeader from "./top-header"
import Navbar from "./navbar";
const Header = ()=>{
    return (
        <div className="hero_area">
            {/* header section strats */}
            <header className="header_section">
                <TopHeader />
                <Navbar />
            </header>

        </div>
    )
}

export default Header;